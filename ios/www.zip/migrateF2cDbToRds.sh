#!/bin/bash
#Usage:   bash migrateF2cDbToRds.sh <rdsHost> <dbUsername> <dbPassword> <dbName>
#步骤:
#1. 创建RDS数据库
#1) 创建RDS
#2) 创建database, 支持字符集选utf-8
#3) 创建RDS帐号，授权读写访问
#4) 把当前企业版机器的内网IP, Nat IP, 公网加入到RDS白名单
#- 如果在同一个地区的VPC网络，把Nat IP加入到RDS白名单
#- 如果在同一个地区的经典网络，把内网IP加入到RDS白名单
#2. 迁移
#1) 登陆企业版虚拟机
#2) 运行迁移脚本，输入RDS主机IP，用户名，密码，数据库名

logFilePath="/var/log/f2c-ops.log"
#Check Rds host, username and password
rdsHost=$1
dbUsername=$2
dbPassword=$3
dbName=$4

#download f2c-ops to /opt

function usage
{
    echo "Usage: bash migrateF2cDBToRds.sh <rdsHost> <dbUsername> <dbPassword> <dbName>"
}

function validateInputParameters
{

  if [ "x${rdsHost}" == "x"  ];then
     echo ERROR: rdsHost is required, current not provided
     usage
     exit 1
  fi

  if [ "x${dbUsername}" == "x"  ];then
     echo ERROR: dbUsername is required, current not provided
     usage
     exit 1
  fi

  if [ "x${dbPassword}" == "x"  ];then
     echo ERROR: dbPassword is required, current not provided
     usage
     exit 1
  fi

  if [ "x${dbName}" == "x"  ];then
     echo ERROR: dbName is required, current not provided
     usage
     exit 1
  fi
}

#Check inputs and if run @ f2c enterprise VM
if [ -f /opt/fit2cloud/fit2cloud.properties ];then
    echo "F2C企业版服务器检查通过!"
else
    echo "错误: 检查是否运行在F2C企业版服务器失败，请登陆到F2C企业版服务器运行！"
    exit 1
fi 

#Stop f2c
function stopF2c 
{
    service fit2cloud stop
}

function startF2c
{
    service fit2cloud start
}

function migrateDbToRds
{
    dumpFileName=f2c-db-aliyun.sql
    rm -rf /tmp/$dumpFileName
	DB_PASSWORD=`cat /opt/fit2cloud/fit2cloud.properties | grep rdb.password | awk -F= '{print $2}'`
	echo "mysqldump -uroot -p$DB_PASSWORD -R fit2cloud > /tmp/$dumpFileName"
	mysqldump -uroot -p$DB_PASSWORD -R fit2cloud > /tmp/$dumpFileName
	
	sed -i "/DEFINER/d" /tmp/$dumpFileName
	sed -i "s/ALGORITHM=UNDEFINED//g" /tmp/$dumpFileName
	
	echo "mysql -h$rdsHost -u$dbUsername -p$dbPassword $dbName < /tmp/$dumpFileName"
	mysql -h$rdsHost -u$dbUsername -p$dbPassword $dbName < /tmp/$dumpFileName >> $logFilePath 2>&1
	output=`mysql -h$rdsHost -u$dbUsername -p$dbPassword $dbName -e "desc server"`
	if [ $? -eq 0 ] ; then
	    echo "数据迁移到RDS成功!"
	    #switch db connection parameters in fit2cloud.properties
		output=`cat /opt/fit2cloud/fit2cloud.properties | grep localhost:3306 | wc -l`
		if [ $output -eq 1 ] ; then
		    cp /opt/fit2cloud/fit2cloud.properties /opt/fit2cloud/fit2cloud.properties.bak
		fi
	    sed -i "s/localhost:3306\/fit2cloud/$rdsHost:3306\/$dbName/g" /opt/fit2cloud/fit2cloud.properties
		sed -i "s/rdb\.user=root/rdb\.user=$dbUsername/g" /opt/fit2cloud/fit2cloud.properties
		sed -i "s/rdb\.password=$DB_PASSWORD/rdb\.password=$dbPassword/g" /opt/fit2cloud/fit2cloud.properties
	else 
	    echo "数据迁移到RDS失败，请联系support@fit2cloud.com!"
	fi
}

validateInputParameters
stopF2c
migrateDbToRds
startF2c
