#!/bin/bash
#Usage:

logFilePath="/var/log/f2c-ops.log"

export repoOSS=True
export password=Fit2cloud2015!
export username=fit2cloud
indents="...."

echo "开始安装FIT2CLOUD..."

if [ -f /opt/f2c-ops/install-fit2cloud.sh ];then
    echo "    说明：请使用干净的系统进行安装，如果该机器已安装Mysql, Apache, Nginx等软件，FIT2CLOUD将无法正常工作."
    echo "    说明：安装日志位于/var/log/f2c-ops.log"
    echo "-----------------------------------"
else
    echo "    错误：install-fit2cloud.sh安装脚本和安装包的路径必须位于/opt/f2c-ops目录下面"
    exit 1
fi

echo 第一步：检查安装环境是否满足要求...
if [ -f /etc/redhat-release ];then
    majorVersion=`cat /etc/redhat-release | grep -oE '[0-9]+\.[0-9]+' | awk -F. '{print $1}'`
    if [ "x$majorVersion" == "x" ];then
        echo "    错误: 操作系统类型版本不符合要求，请使用CentOS6.x, Redhat6.x版本"
        exit 1
    else
       if [ "x$majorVersion" == "x6" ];then 
           echo "    操作系统检查通过!"
       else 
           echo "    错误: 操作系统类型版本不符合要求，请使用CentOS6.x, Redhat6.x版本"
           exit 1
       fi
    fi
else
    echo "    错误: 操作系统类型版本不符合要求，请使用CentOS6.x, Redhat6.x版本"
    exit 1
fi

sleep 2
is64bitArch=`uname -m`
if [ "x$is64bitArch" == "xx86_64" ];then
   echo "    操作系统是64位!"
else
   echo "    错误: 操作系统必须是64位的，32位的不支持"
   exit 1
fi

sleep 2
isUTFEncoding=`echo $LANG grep UTF-8 | wc -l`
if [ "x$isUTFEncoding" == "x1" ];then
   echo "    locale检查通过!"
else
   echo "    错误: locale必须是UTF-8字符集"
   exit 1
fi

sleep 2
isRoot=`id -u -n | grep root | wc -l`
if [ "x$isRoot" == "x1" ];then
   echo "    root用户检查通过!"
else
   echo "    错误: 请用root用户执行安装脚本"
   exit 1
fi

sleep 2
memTotal=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
if [ $memTotal -gt 7680000 ];then
   echo "    内存大小检查通过!"
else
   echo "    错误: 内存不足，最小内存要求是7.5G"
   exit 1
fi

echo "    环境检查完毕."
echo "-----------------------------------"
sleep 2

echo "第二步：配置运行时环境(大约需要5到10分钟)..."
cd /opt/f2c-ops
./3-configure-env-os.sh -a all >> $logFilePath
echo "    运行时环境配置完毕."
echo "-----------------------------------"
sleep 2

echo 第三步：安装MySQL数据库...
./1-mysql.sh -a install >> $logFilePath
echo "    MySQL安装完毕."
echo "-----------------------------------"
sleep 2

echo 第四步：安装RabbitMQ...
./2-rabbitmq.sh -a install >> $logFilePath
echo "    RabbitMQ安装完毕."
echo "-----------------------------------"
sleep 2

echo 第五步:安装Haproxy...
./4-haproxy.sh -a install >> $logFilePath
echo "    HAProxy安装完毕."
echo "-----------------------------------"
sleep 2

echo 第六步:安装Apache...
./5-apache.sh -a install >> $logFilePath
echo "    Apache安装完毕."
echo "-----------------------------------"
sleep 2

echo 第七步:安装FIT2CLOUD组件...
./f2c-ops.sh -a deploycode -c f2c -v 0.2
./6-f2c-plugin.sh -a install -p aws -v 0.2
./6-f2c-plugin.sh -a install -p aliyun -v 0.2
./6-f2c-plugin.sh -a install -p qingcloud -v 0.2
./6-f2c-plugin.sh -a install -p ucloud -v 0.2
./6-f2c-plugin.sh -a install -p qcloud -v 0.2
./6-f2c-plugin.sh -a install -p azure -v 0.2
./6-f2c-plugin.sh -a install -p ksyun -v 0.2
sleep 2

cp etc/init.d/fit2cloud /etc/init.d
chmod a+x /etc/init.d/fit2cloud
chkconfig --level 345 iptables on
chkconfig --level 345 mysqld on
chkconfig --level 345 haproxy on
chkconfig --level 345 httpd on
chkconfig --level 345 rabbitmq-server on
chkconfig --level 345 fit2cloud on

echo FIT2CLOUD安装完毕! 
echo 你可以使用service命令管理fit2cloud, 支持的操作包括: [start, stop, restart, status, upgrade]

echo "-----------------------------------"

echo 第八步:启动FIT2CLOUD服务...
service fit2cloud start

echo 访问用地址为: http://机器IP/
echo 管理员信息在: /opt/fit2cloud/Readme.txt

