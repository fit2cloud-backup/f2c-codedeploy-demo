#!/bin/bash
newPassword=`uuidgen`
rabbitmqctl change_password fit2cloud ${newPassword} 
sed -i "s/rabbitmq.password=Fit2cloud2015!/rabbitmq.password=${newPassword}/g" /opt/fit2cloud/fit2cloud.properties
sed -i "s/Fit2cloud2015!/${newPassword}/g" /opt/fit2cloud/job.xml	
service fit2cloud stop
service fit2cloud start

