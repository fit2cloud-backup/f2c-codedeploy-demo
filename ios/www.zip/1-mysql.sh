#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

while getopts a:h option
do
    case "$option" in
        a)
            action=$OPTARG
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            exit 1;;
    esac
done

baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)

function startMySQL
{
  username=root
  password=${password}
  databaseName=fit2cloud
  /etc/rc.d/init.d/mysqld stop 2>&1 
  /etc/rc.d/init.d/mysqld start 2>&1 
  mysql -u root -p$password $databaseName -e "select 1" 2>&1 
  if [ $? == 0 ];then
      echo "root密码，数据库，权限已初始化!" 
  else
     mysqladmin -u root password $password 2>&1 
     mysql -u root -p$password -e "create database $databaseName" 2>&1 
     /etc/rc.d/init.d/mysqld restart 2>&1     
  fi
}

function resetDB
{
  baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)
  username=root
  password=${password}
  databaseName=fit2cloud
  mysql -u$username -p$password -e "drop database $databaseName;" 2>&1 
  mysql -u$username -p$password -e "create database $databaseName;" 2>&1 
}

if [ "$action" == "install"  ];then
  mysql_install_db  2>&1 
  chown -R mysql:mysql /var/lib/mysql
  cp $baseDirForScriptSelf/conf/my.cnf.template /etc/my.cnf
  which mysql > /dev/null 2>&1
  if [ $? == 0 ];then
      startMySQL
      resetDB
  else
      echo "错误: mysql安装失败!"
      exit 1
  fi
fi

if [ "$action" ==  "reset" ];then
  resetDB
fi
