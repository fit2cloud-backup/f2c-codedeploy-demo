#!/bin/bash
nodeType=$1
masterIp=$2
slaveIp=$3
masterDbUsername=$4
masterDbPassword=$5
slaveDbUsername=$6
slaveDbPassword=$7

function usage
{
  echo "Usage: bash mysql-config.sh <nodeType> <masterIp> <slaveIp> <masterDbUsername> <masterDbPassword> <slaveDbUsername> <slaveDbPassword>"
  echo ""
  echo "nodeType : master | slave"
}

function validateInputParameters
{

  if [ "x${masterIp}" == "x"  ];then
     echo ERROR: masterIp is required, current not provided
     usage
     exit 1
  fi

  if [ "x${slaveIp}" == "x"  ];then
     echo ERROR: slaveIp is required, current not provided
     usage
     exit 1
  fi

  if [ "x${nodeType}" == "x"  ];then
     echo ERROR: nodeType is required, current not provided
     usage
     exit 1
  fi

  if [ "x${masterDbUsername}" == "x"  ];then
     echo ERROR: masterDbUsername is required, current not provided
     usage
     exit 1
  fi

  if [ "x${masterDbPassword}" == "x"  ];then
     echo ERROR: masterDbPassword is required, current not provided
     usage
     exit 1
  fi

  if [ "x${slaveDbUsername}" == "x"  ];then
     echo ERROR: slaveDbUsername is required, current not provided
     usage
     exit 1
  fi

  if [ "x${slaveDbPassword}" == "x"  ];then
     echo ERROR: slaveDbPassword is required, current not provided
     usage
     exit 1
  fi
}

function configMysql
{
  echo "start to config mysql [${nodeType}]..."
  service mysqld start
  if [ "${nodeType}" == "master"  ];then
    /usr/bin/mysqladmin -u ${masterDbUsername} password ${masterDbPassword}
    # enable port 3306
    /sbin/iptables -I INPUT -p tcp --dport 3306 -j ACCEPT
    /etc/init.d/iptables save
    service iptables restart
  fi
  if [ "${nodeType}" == "slave"  ];then
    /usr/bin/mysqladmin -u ${slaveDbUsername} password ${slaveDbPassword}
  fi
  echo "edit /etc/my.cnf ..."
  echo -e "[mysqld]
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
user=mysql
bind-address=0.0.0.0
default-character-set=utf8
character_set_server=utf8
lower_case_table_names=1
symbolic-links=0
query_cache_size=16M
thread_cache_size=8
table_open_cache=128
innodb_buffer_pool_size=1G

[mysqld_safe]
log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid
default-character-set=utf8

[mysql]
default-character-set=utf8

[mysql.server]
default-character-set=utf8

[client]
default-character-set=utf8" > /etc/my.cnf

  if [ "${nodeType}" == "master"  ];then
    echo "config master node ..."
    sed -i '/\[mysqld\]/a\log-bin=mysql-bin\n\server-id=1' /etc/my.cnf
    service mysqld restart
    echo "grant privileges ..."
    mysql -u${masterDbUsername} -p${masterDbPassword} -e "grant replication slave on *.* to '${masterDbUsername}'@'${slaveIp}' identified by '${masterDbPassword}';"
    mysql -u${masterDbUsername} -p${masterDbPassword} -e "grant all privileges on *.* to '${masterDbUsername}'@'${slaveIp}' identified by '${masterDbPassword}' with grant option;"
  fi

  if [ "${nodeType}" == "slave"  ];then
    echo "config slave node ..."
    sed -i '/\[mysqld\]/a\log-bin=mysql-bin\n\server-id=2' /etc/my.cnf
    service mysqld restart
    echo "change master ..."
    mysql -u${slaveDbUsername} -p${slaveDbPassword} -e "change master to master_host='${masterIp}', master_port=3306,master_user='${masterDbUsername}',master_password='${masterDbPassword}',master_log_file='mysql-bin.000001',master_log_pos=0;start slave;"
  fi
}

validateInputParameters
configMysql
