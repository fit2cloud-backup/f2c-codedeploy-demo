#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

while getopts a:p:v:h option
do
    case "$option" in
        a)
            action=$OPTARG
            ;;
        p)
            providerId=$OPTARG
            ;;
        v)
            version=$OPTARG
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            exit 1;;
    esac
done

DEBUG=0
if [ $DEBUG -eq 1 ];then
  echo action=$action
  echo providerId=$providerId
  echo version=$version
fi

baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)

wgetRetries=3
wgetTimeout=60
mkdir -p /opt/fit2cloud/plugins
pluginName=fit2cloud-$providerId-plugin-$version-jar-with-dependencies.jar
pluginNamePrefix=fit2cloud-$providerId-plugin-$version-jar-with-dependencies

if [ "$action" == "install"  ];then
  output=`cp /opt/f2c-ops/plugins/$pluginName /opt/fit2cloud/plugins/$pluginName 2>&1 >> $logFilePath`
  if [ -f /opt/fit2cloud/plugins/$pluginName ];then
      echo "$providerId plugin installed!"
  else 
      echo "错误: $providerId 插件安装失败!"
      exit 1
  fi
fi

if [ "$action" == "redeploy"  ];then
  realPluginName=`ls /opt/fit2cloud/plugins/$pluginNamePrefix*.jar 2>&1`
  if [ $? == 0 ];then
     if [ -f $realPluginName ];then
         output=`rm -rf $realPluginName 2>&1 >> $logFilePath`
         output=`cp /opt/f2c-ops/plugins/$pluginName /opt/fit2cloud/plugins/$pluginName 2>&1 >> $logFilePath`
         echo "$providerId plugin installed!"
     fi
   fi
fi
