#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

while getopts a:h option
do
    case "$option" in
        a)
            #echo "option:i, value $OPTARG"
            action=$OPTARG
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            #usage
            exit 1;;
    esac
done

function configureFileMax
{
  echo Configure fs.file-max to 655535
  sysctlPath=/etc/sysctl.conf
  sed -i '/file-max/d' $sysctlPath
  echo "fs.file-max = 65535" >> $sysctlPath
}

function configureSecurityLimits
{
  securityLimitsPath=/etc/security/limits.conf
  sed -i "/mysql/d" $securityLimitsPath
  sed -i "/root/d" $securityLimitsPath
  sed -i "/rabbitmq/d" $securityLimitsPath

  cat << EOF >> $securityLimitsPath
mysql         soft     nproc          63535
mysql         hard     nproc          63535
mysql         soft     nofile         63535
mysql         hard     nofile         63535
root          soft     nproc          63535
root          hard     nproc          63535
root          soft     nofile         63535
root          hard     nofile         63535
rabbitmq          soft     nproc          63535
rabbitmq          hard     nproc          63535
rabbitmq          soft     nofile         63535
rabbitmq          hard     nofile         63535
EOF

}

function configureEnvVariables
{
  sed -i "/ulimit -u 63530/d" ~/.bash_profile
  sed -i "/export PATH/d" ~/.bash_profile
  cat << EOF >> ~/.bash_profile
ulimit -u 63530
HOME=/root
export PATH
EOF
  source ~/.bash_profile
}

function configureIptables
{
  cp conf/iptables.template /etc/sysconfig/iptables 
  service iptables restart
}

baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)

if [ "$action" == "all"  ];then
    configureFileMax
    configureSecurityLimits
    configureEnvVariables
    configureIptables
    rpm -iv /opt/f2c-ops/rpm/*.rpm --force --nodeps > /dev/null 2>&1
    majorVersion=`cat /etc/redhat-release | grep CentOS | wc -l`
    if [ "x$majorVersion" == "1x" ];then
        rpm -i /opt/f2c-ops/rpm/centos6/*.rpm --force --nodeps > /dev/null 2>&1
    else
        rpm -i /opt/f2c-ops/rpm/rhel6/*.rpm --force --nodeps > /dev/null 2>&1
    fi
    bash /opt/f2c-ops/patch_jdk.sh
    service ntpd restart
fi    

if [ "$action" == "iptables"  ];then
    configureIptables
fi

if [ "$action" == "env"  ];then
    configureEnvVariables
fi
