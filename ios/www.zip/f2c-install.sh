#!/bin/bash

logFilePath="/var/log/f2c-install-eventagent.log"

function usage
{
  echo "Usage: f2c-install -c <cmdName> -l <sourceLink> -t <timeout in secs> -v <valiedateUseCmdName>"
  echo "Examples:"
  echo "f2c-install -c gcc -t 180"
  echo "f2c-install -c tar -t 60"
  echo "f2c-install -c curl -t 60"
  echo "f2c-install -c gcc-c++ -v g++"
  echo "f2c-install -c zlib -l http://f2c-repo-pub.oss-cn-hangzhou.aliyuncs.com/eventagent-runtimes/zlib-1.2.8.tar.gz"
  echo "f2c-install -c python2.7 -l http://f2c-repo-pub.oss-cn-hangzhou.aliyuncs.com/eventagent-runtimes/Python-2.7.tar.gz -t 120"
  echo "f2c-install -c setuptools -l http://f2c-repo-pub.oss-cn-hangzhou.aliyuncs.com/eventagent-runtimes/setuptools-0.7.2.tar.gz"
  echo "f2c-install -c dos2unix -l http://f2c-repo-pub.oss-cn-hangzhou.aliyuncs.com/eventagent-runtimes/dos2unix-7.2.2.tar.gz"
}

while getopts c:l:t:v: option
do
    case "$option" in
        c)
            #echo "option:c, value $OPTARG"
            cmdName=$OPTARG
            ;;
        l)
            #echo "option:l, value $OPTARG"
            cmdSourceUrl=$OPTARG
            ;;
        t)
            #echo "option:l, value $OPTARG"
            timeoutTime=$OPTARG
            ;;
        v)
            #echo "option:l, value $OPTARG"
            validateName=$OPTARG
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            #usage
            exit 1;;
    esac
done

DEBUG=0
if [ $DEBUG -eq 1 ];then
  echo cmdName=$cmdName
  echo cmdSourceUrl=$cmdSourceUrl
  echo timeoutTime=$timeoutTime
  echo validateName=$validateName
fi

#Validate componentId
function validateCommandName
{
    if [ "x$cmdName" == "x" ]; then
        echo ERROR: cmdName is required
        usage
        exit 1
    fi
}
validateCommandName

if [ "x$timeoutTime" == "x" ];then
  timeoutTime=120
fi

if [ "x$validateName" == "x" ];then
  validateName=$cmdName
fi

function installTimeout
{
  output=`timeout --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" != "0" ]; then
      echo `date "+%Y-%m-%d %H:%M:%S"`": timeout不存在，正在安装..." 
      echo `date "+%Y-%m-%d %H:%M:%S"`": timeout不存在，正在安装" >> $logFilePath
      echo -n "IyEvYmluL3NoCmlmIFsgIiQjIiAtbHQgIjIiIF07IHRoZW4KICAgIGVjaG8gIlVzYWdlOiAgIHRpbWVvdXQgdGltZW91dF9pbl9zZWNvbmRzIGNvbW1hbmQiID4mMgogICAgZWNobyAiRXhhbXBsZTogdGltZW91dCAyIHNsZWVwIDMgfHwgZWNobyB0aW1lb3V0IiA+JjIKICAgIGV4aXQgMQpmaQoKY2xlYW51cCgpCnsKICAgIHRyYXAgLSBBTFJNICAgICAgICAgICAgICAgI3Jlc2V0IGhhbmRsZXIgdG8gZGVmYXVsdAogICAga2lsbCAtQUxSTSAkYSAyPi9kZXYvbnVsbCAjc3RvcCB0aW1lciBzdWJzaGVsbCBpZiBydW5uaW5nCiAgICBraWxsICQhIDI+L2Rldi9udWxsICYmICAgICNraWxsIGxhc3Qgam9iCiAgICAgIGV4aXQgMTI0ICAgICAgICAgICAgICAgICNleGl0IHdpdGggMTI0IGlmIGl0IHdhcyBydW5uaW5nCn0KCndhdGNoaXQoKQp7CiAgICB0cmFwICJjbGVhbnVwIiBBTFJNCiAgICBzbGVlcCAkMSYgd2FpdAogICAga2lsbCAtQUxSTSAkJAp9Cgp3YXRjaGl0ICQxJiBhPSQhICAgICAgICAgI3N0YXJ0IHRoZSB0aW1lb3V0CnNoaWZ0ICAgICAgICAgICAgICAgICAgICAjZmlyc3QgcGFyYW0gd2FzIHRpbWVvdXQgZm9yIHNsZWVwCnRyYXAgImNsZWFudXAiIEFMUk0gSU5UICAjY2xlYW51cCBhZnRlciB0aW1lb3V0CiIkQCImIHdhaXQgJCE7IFJFVD0kPyAgICAjc3RhcnQgdGhlIGpvYiB3YWl0IGZvciBpdCBhbmQgc2F2ZSBpdHMgcmV0dXJuIHZhbHVlCmtpbGwgLUFMUk0gJGEgICAgICAgICAgICAjc2VuZCBBTFJNIHNpZ25hbCB0byB3YXRjaGl0CndhaXQgJGEgICAgICAgICAgICAgICAgICAjd2FpdCBmb3Igd2F0Y2hpdCB0byBmaW5pc2ggY2xlYW51cApleGl0ICRSRVQgICAgICAgICAgICAgICAgI3JldHVybiB0aGUgdmFsdWUK"  | base64 --decode > /usr/bin/timeout
      echo `date "+%Y-%m-%d %H:%M:%S"`": timeout安装完毕!" 
      chmod a+x /usr/bin/timeout
  fi  
}
installTimeout

function installF2ctimeout
{
  output=`f2c-timeout --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" != "0" ]; then
        echo `date "+%Y-%m-%d %H:%M:%S"`": f2c-timeout不存在，正在安装..." 
        echo `date "+%Y-%m-%d %H:%M:%S"`": f2c-timeout不存在，正在安装" >> $logFilePath
        script="IyEvYmluL2Jhc2gKIwojIFRoZSBCYXNoIHNoZWxsIHNjcmlwdCBleGVjdXRlcyBhIGNvbW1hbmQgd2l0aCBhIHRpbWUtb3V0LgojIFVwb24gdGltZS1vdXQgZXhwaXJhdGlvbiBTSUdURVJNICgxNSkgaXMgc2VudCB0byB0aGUgcHJvY2Vzcy4gSWYgdGhlIHNpZ25hbAojIGlzIGJsb2NrZWQsIHRoZW4gdGhlIHN1YnNlcXVlbnQgU0lHS0lMTCAoOSkgdGVybWluYXRlcyBpdC4KIwojIEJhc2VkIG9uIHRoZSBCYXNoIGRvY3VtZW50YXRpb24gZXhhbXBsZS4KCnNjcmlwdE5hbWU9IiR7MCMjKi99IgoKZGVjbGFyZSAtaSBERUZBVUxUX1RJTUVPVVQ9MTIwMApkZWNsYXJlIC1pIERFRkFVTFRfSU5URVJWQUw9MQpkZWNsYXJlIC1pIERFRkFVTFRfREVMQVk9MQoKIyBUaW1lb3V0LgpkZWNsYXJlIC1pIHRpbWVvdXQ9REVGQVVMVF9USU1FT1VUCiMgSW50ZXJ2YWwgYmV0d2VlbiBjaGVja3MgaWYgdGhlIHByb2Nlc3MgaXMgc3RpbGwgYWxpdmUuCmRlY2xhcmUgLWkgaW50ZXJ2YWw9REVGQVVMVF9JTlRFUlZBTAojIERlbGF5IGJldHdlZW4gcG9zdGluZyB0aGUgU0lHVEVSTSBzaWduYWwgYW5kIGRlc3Ryb3lpbmcgdGhlIHByb2Nlc3MgYnkgU0lHS0lMTC4KZGVjbGFyZSAtaSBkZWxheT1ERUZBVUxUX0RFTEFZCgpmdW5jdGlvbiBwcmludFVzYWdlKCkgewpjYXQgPDxFT0YKClN5bm9wc2lzCiRzY3JpcHROYW1lIFstdCB0aW1lb3V0XSBbLWkgaW50ZXJ2YWxdIFstZCBkZWxheV0gY29tbWFuZApFeGVjdXRlIGEgY29tbWFuZCB3aXRoIGEgdGltZS1vdXQuClVwb24gdGltZS1vdXQgZXhwaXJhdGlvbiBTSUdURVJNICgxNSkgaXMgc2VudCB0byB0aGUgcHJvY2Vzcy4gSWYgU0lHVEVSTQpzaWduYWwgaXMgYmxvY2tlZCwgdGhlbiB0aGUgc3Vic2VxdWVudCBTSUdLSUxMICg5KSB0ZXJtaW5hdGVzIGl0LgoKLXQgdGltZW91dApOdW1iZXIgb2Ygc2Vjb25kcyB0byB3YWl0IGZvciBjb21tYW5kIGNvbXBsZXRpb24uCkRlZmF1bHQgdmFsdWU6ICRERUZBVUxUX1RJTUVPVVQgc2Vjb25kcy4KCi1pIGludGVydmFsCkludGVydmFsIGJldHdlZW4gY2hlY2tzIGlmIHRoZSBwcm9jZXNzIGlzIHN0aWxsIGFsaXZlLgpQb3NpdGl2ZSBpbnRlZ2VyLCBkZWZhdWx0IHZhbHVlOiAkREVGQVVMVF9JTlRFUlZBTCBzZWNvbmRzLgoKLWQgZGVsYXkKRGVsYXkgYmV0d2VlbiBwb3N0aW5nIHRoZSBTSUdURVJNIHNpZ25hbCBhbmQgZGVzdHJveWluZyB0aGUKcHJvY2VzcyBieSBTSUdLSUxMLiBEZWZhdWx0IHZhbHVlOiAkREVGQVVMVF9ERUxBWSBzZWNvbmRzLgoKQXMgb2YgdG9kYXksIEJhc2ggZG9lcyBub3Qgc3VwcG9ydCBmbG9hdGluZyBwb2ludCBhcml0aG1ldGljIChzbGVlcCBkb2VzKSwKdGhlcmVmb3JlIGFsbCBkZWxheS90aW1lIHZhbHVlcyBtdXN0IGJlIGludGVnZXJzLgpFT0YKfQoKIyBPcHRpb25zLgp3aGlsZSBnZXRvcHRzICI6dDppOmQ6IiBvcHRpb247IGRvCmNhc2UgIiRvcHRpb24iIGluCnQpIHRpbWVvdXQ9JE9QVEFSRyA7OwppKSBpbnRlcnZhbD0kT1BUQVJHIDs7CmQpIGRlbGF5PSRPUFRBUkcgOzsKKikgcHJpbnRVc2FnZTsgZXhpdCAxIDs7CmVzYWMKZG9uZQpzaGlmdCAkKChPUFRJTkQgLSAxKSkKCiMgJCMgc2hvdWxkIGJlIGF0IGxlYXN0IDEgKHRoZSBjb21tYW5kIHRvIGV4ZWN1dGUpLCBob3dldmVyIGl0IG1heSBiZSBzdHJpY3RseQojIGdyZWF0ZXIgdGhhbiAxIGlmIHRoZSBjb21tYW5kIGl0c2VsZiBoYXMgb3B0aW9ucy4KaWYgKCgkIyA9PSAwIHx8IGludGVydmFsIDw9IDApKTsgdGhlbgpwcmludFVzYWdlCmV4aXQgMQpmaQoKIyBraWxsIC0wIHBpZCAgIEV4aXQgY29kZSBpbmRpY2F0ZXMgaWYgYSBzaWduYWwgbWF5IGJlIHNlbnQgdG8gJHBpZCBwcm9jZXNzLgooCigodCA9IHRpbWVvdXQpKQoKd2hpbGUgKCh0ID4gMCkpOyBkbwpzbGVlcCAkaW50ZXJ2YWwKa2lsbCAtMCAkJCB8fCBleGl0IDAKKCh0IC09IGludGVydmFsKSkKZG9uZQoKIyBCZSBuaWNlLCBwb3N0IFNJR1RFUk0gZmlyc3QuCiMgVGhlICdleGl0IDAnIGJlbG93IHdpbGwgYmUgZXhlY3V0ZWQgaWYgYW55IHByZWNlZWRpbmcgY29tbWFuZCBmYWlscy4KcGlkPSQkCmVjaG8gY3VycmVudCBzY3JpcHQgUElEPSRwaWQKCmVjaG8gW0VSUk9SXSBbVElNRU9VVF0gJHRpbWVvdXQgc2VjcyB0aW1lb3V0IHJlYWNoZWQgd2hlbiBleGVjdXRpbmc6IFwiJEBcIgpwa2lsbCAtVEVSTSAtUCAkcGlkCgpraWxsIC1zIFNJR1RFUk0gJCQgJiYga2lsbCAtMCAkJCB8fCBleGl0IDAKc2xlZXAgJGRlbGF5CmtpbGwgLXMgU0lHS0lMTCAkJAopIDI+IC9kZXYvbnVsbCAmCgpleGVjICIkQCIK"
        echo -n $script | base64 --decode > /usr/bin/f2c-timeout
        echo `date "+%Y-%m-%d %H:%M:%S"`": f2c-timeout安装完毕!" 
        chmod a+x /usr/bin/f2c-timeout
        cp /usr/bin/f2c-timeout /usr/bin/f2ctimeout
        chmod a+x /usr/bin/f2ctimeout
  fi
}
installF2ctimeout

function installF2cWget
{
  envBinPath=`which env`
  output=`f2c-wget --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" != "0" ]; then
      echo "#!$envBinPath python" > /usr/bin/f2c-wget
      cat <<\EOF >> /usr/bin/f2c-wget

import sys, urllib, os

def reporthook(*a) :
  sys.stdout.write('.'),

for url in sys.argv[1:]:
  i = url.rfind('/')
  file_name = url[i+1:]
  print '\nStart download -->'
  print url
  print 'download to ' + os.getcwd() + '/' + file_name + '\n'
  urllib.urlretrieve(url, file_name, reporthook)
  print "file_name=%s" % file_name
  print ""
EOF
      chmod a+x /usr/bin/f2c-wget
      echo `date "+%Y-%m-%d %H:%M:%S"`": f2c-wget安装完毕!" 
  fi
}
installF2cWget

installed=True
output=`$validateName --help 2>&1 | grep "command not found" | wc -l`
if [ "$output" == "1" ]; then
    installed=False
else
    installed=True
    echo `date "+%Y-%m-%d %H:%M:%S"`: "$cmdName already installed!"
    exit 0
fi

function configureCentOSRepo
{
  if [ -f /etc/yum.repos.d/epel.repo ];then
      echo "epel-release已安装" >> $logFilePath
	  output=`rm -rf /etc/yum.repos.d/rpmfusion* 2>&1 >> $logFilePath`
      output=`yum upgrade -y ca-certificates --disablerepo=epel`
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`: "安装epel-release..."
      output=`rm -rf /etc/yum.repos.d/rpmfusion* 2>&1 >> $logFilePath`
      output=`yum install -y epel-release 2>&1 >> $logFilePath`
      echo `date "+%Y-%m-%d %H:%M:%S"`: "安装epel-release完毕!"
      output=`yum upgrade -y ca-certificates --disablerepo=epel`
  fi
}

function configureUbuntuRepo
{
  export LC_ALL="en_US.UTF-8"
  echo `date "+%Y-%m-%d %H:%M:%S"`: "进行apt-get update..."
  output=`apt-get update 2>&1 >> $logFilePath`
  echo `date "+%Y-%m-%d %H:%M:%S"`: "apt-get update结束!"
  if [ -f /etc/apt/listchanges.conf ] ; then
     if [ "$output" == "0" ];then
       sed -i "s/frontend=pager/frontend=text/g" /etc/apt/listchanges.conf
     fi
     output=`apt-get remove -y apt-listchanges 2>&1 >> $logFilePath`
     echo $output >> $logFilePath
  fi  
}

function configureDebianRepo
{
  majorVersion=`lsb_release -r | awk '{print $2}' | awk -F. '{print $1}'`
  if [ $majorVersion -ge 6 ] ; then
      output=`grep "mirrors.163.com/debian" /etc/apt/sources.list | wc -l`
      if [ $output -eq 0 ] ; then
         cat << EOF >> /etc/apt/sources.list
deb http://mirrors.163.com/debian wheezy main non-free contrib
deb-src http://mirrors.163.com/debian wheezy main non-free contrib

deb http://mirrors.163.com/debian wheezy-updates main non-free contrib
deb-src http://mirrors.163.com/debian wheezy-updates main non-free contrib
EOF
         output=`apt-get update 2>&1 >> $logFilePath`
         if [ -f /etc/apt/listchanges.conf ] ; then
            sed -i "s/frontend=pager/frontend=text/g" /etc/apt/listchanges.conf
         fi
         output=`apt-get remove -y apt-listchanges 2>&1 >> $logFilePath`
      fi
  fi
}

#4. install runtimes
function configureRepo
{
  echo `date "+%Y-%m-%d %H:%M:%S"`: "configuring repo..."
  repoConfigured=""
  if [ -f /etc/redhat-release ];then
      repoConfigured="yum repo"
      configureCentOSRepo
  fi
  if [ -f /etc/issue ];then
      currentOS=`cat /etc/issue | head -n 1  | awk '{print $1}'`
      if [ "$currentOS" == "Ubuntu" ] ; then
          repoConfigured="apt-get repo"
          configureUbuntuRepo
      elif [ "$currentOS" == "Debian" ] ; then
          repoConfigured="apt-get repo"
          configureDebianRepo
      elif [ "$currentOS" == "Amazon" ] ; then
          repoConfigured="yum repo"
          configureCentOSRepo
      fi
  fi
  if [ "$repoConfigured" != "" ];then
    echo `date "+%Y-%m-%d %H:%M:%S"`: "$repoConfigured is configured!"
  else
    echo `date "+%Y-%m-%d %H:%M:%S"`: "Unregnized OS, repo is not configured, /etc/redhat-release and /etc/issue do not exist"
  fi
}

function validateSourceInstallRequiredRuntimes
{
  notInstalled=""
  validateToolInstalled curl
  if [ $? != 0 ];then
      notInstalled="$notInstalled curl"
  fi

  validateToolInstalled tar
  if [ $? != 0 ];then
      notInstalled="$notInstalled tar"
  fi

  validateToolInstalled make
  if [ $? != 0 ];then
      notInstalled="$notInstalled make"
  fi

  validateToolInstalled gcc
  if [ $? != 0 ];then
      notInstalled="$notInstalled gcc"
  fi

  if [ "$notInstalled" != "" ];then
      echo `date "+%Y-%m-%d %H:%M:%S"`: "错误:$notInstalled is required, please first install it!"
      exit 1
  fi
}

function installZlib
{
  mkdir -p /tmp/fit2cloud
  cd /tmp/fit2cloud
  
  validateSourceInstallRequiredRuntimes

  output=`curl -L -o /tmp/fit2cloud/zlib-1.2.8.tar.gz --retry 3 --retry-delay 5 --connect-timeout 10 -m 180 $cmdSourceUrl 2>&1 >> $logFilePath`

  if [ -f /tmp/fit2cloud/zlib-1.2.8.tar.gz ]; then
      echo "/tmp/fit2cloud/zlib-1.2.8.tar.gz exists" >> $logFilePath
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`: "ERROR: zlib-1.2.8.tar.gz download failed, /tmp/fit2cloud/zlib-1.2.8.tar.gz does not exist!"
      exit 1
  fi

  echo `date "+%Y-%m-%d %H:%M:%S"`: "解压缩安装文件zlib-1.2.8.tar.gz ..."
  tar -zxvf zlib-1.2.8.tar.gz >> $logFilePath
  cd zlib-1.2.8
  echo `date "+%Y-%m-%d %H:%M:%S"`": 进行./configure ..."
  output=`./configure 2>&1 >> $logFilePath`
  echo `date "+%Y-%m-%d %H:%M:%S"`": ./configure完毕!"
  echo `date "+%Y-%m-%d %H:%M:%S"`": 进行make ..."
  output=`make 2>&1 >> $logFilePath`
  echo `date "+%Y-%m-%d %H:%M:%S"`": 进行make install ..."
  output=`make install 2>&1 >> $logFilePath`
  if [ $? == 0 ];then
      echo `date "+%Y-%m-%d %H:%M:%S"`": zlib installed successfully!"
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`": zlib installed failed!"
  fi
}

function installPython27
{
  validateSourceInstallRequiredRuntimes

  mkdir -p /tmp/fit2cloud
  cd /tmp/fit2cloud
  output=`curl -L -o /tmp/fit2cloud/Python-2.7.tar.gz --retry 3 --retry-delay 5 --connect-timeout 10 -m 180 $cmdSourceUrl 2>&1 >> $logFilePath`

  if [ -f /tmp/fit2cloud/Python-2.7.tar.gz ]; then
      echo "/tmp/fit2cloud/Python-2.7.tar.gz exists" >> $logFilePath
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`: "ERROR: Python-2.7.tar.gz download failed, /tmp/fit2cloud/Python-2.7.tar.gz does not exist!"
      exit 1
  fi

  echo `date "+%Y-%m-%d %H:%M:%S"`: "解压缩安装文件Python-2.7.tar.gz ..."
  tar -zxvf Python-2.7.tar.gz >> $logFilePath
  cd Python-2.7
  echo `date "+%Y-%m-%d %H:%M:%S"`": 进行./configure, 需要大概几分钟时间，请耐心等待..."
  echo `date "+%Y-%m-%d %H:%M:%S"`: "./configure --prefix=/usr/local/python2.7 --with-zlib --with-ssl"
  output=`./configure --prefix=/usr/local/python2.7 --with-zlib --with-ssl 2>&1 >> $logFilePath`
  echo `date "+%Y-%m-%d %H:%M:%S"`": ./configure完毕!"
  
  output=`make --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" == "1" ]; then
      echo `date "+%Y-%m-%d %H:%M:%S"`: "错误: make没有安装，请安装make后再试,"
      echo `date "+%Y-%m-%d %H:%M:%S"`: "如果已安装f2c-install: f2c-install -c make"
      echo `date "+%Y-%m-%d %H:%M:%S"`: "如果是CentOS系列: yum install -y make"
      echo `date "+%Y-%m-%d %H:%M:%S"`: "如果是Ubuntu系列: apt-get install -y make"
      exit 1
  fi

  echo `date "+%Y-%m-%d %H:%M:%S"`": 进行make, 需要大概几分钟时间，请耐心等待..."
  output=`make 2>&1  >> $logFilePath`
  echo `date "+%Y-%m-%d %H:%M:%S"`": 进行make install, 需要大概几分钟时间，请耐心等待..."
  output=`make install 2>&1  >> $logFilePath`
  echo `date "+%Y-%m-%d %H:%M:%S"`": make install完毕!"
  
  if [ -f /usr/local/python2.7/bin/python2.7 ];then
      output=`ln -sv /usr/local/python2.7/bin/python2.7 /usr/bin/python2.7 2>&1 >> $logFilePath`
      echo `date "+%Y-%m-%d %H:%M:%S"`": 安装Python2.7完毕!" 
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`: "错误: 安装Python2.7失败, /usr/local/python2.7/bin/python2.7不存在!"
      exit 1
  fi
  output=`python2.7 --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" == "0" ]; then
      echo `date "+%Y-%m-%d %H:%M:%S"`: "python2.7 installed successfully!"
      exit 0
  fi
}

function installPythonSetupTools
{
  pythonVersion=`python -V 2>&1 | awk '{print $2}' | awk -F. '{print $1"."$2}'`
  pythonMajorVersion=`python -V 2>&1 | awk '{print $2}' | awk -F. '{print $1}'`
  pythonMinorVersion=`python -V 2>&1 | awk '{print $2}' | awk -F. '{print $2}'`
  
  output=`python2.7 --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" == "0" ]; then
      echo `which python2.7`  >> $logFilePath
      echo "python2.7 exists" >> $logFilePath
  else
      if [ $pythonMajorVersion -eq 2 ] && [ $pythonMinorVersion -lt 6 ] ; then
          echo `date "+%Y-%m-%d %H:%M:%S"`: "error: python2.6 upper is required, please first install python2.7!"
          exit 1
      else
          python27Bin=`which python`
          output=`ln -s $python27Bin /usr/bin/python2.7`
      fi
  fi

  output=`python2.7 -c "from setuptools import setup, find_packages" 2>&1 >> $logFilePath`
  if [ $? == 0 ]; then
    echo `date "+%Y-%m-%d %H:%M:%S"`: "python-setuptools already installed!"
    exit 0
  fi

  echo `date "+%Y-%m-%d %H:%M:%S"`: "安装Setuptools..."
  mkdir -p /tmp/fit2cloud
  validateSourceInstallRequiredRuntimes
  
  echo `date "+%Y-%m-%d %H:%M:%S"`: "Setuptools source link is $cmdSourceUrl"
  output=`curl -L -o /tmp/fit2cloud/setuptools-0.7.2.tar.gz --retry 3 --retry-delay 5 --connect-timeout 10 -m 180 $cmdSourceUrl 2>&1 >> $logFilePath`
  cd /tmp/fit2cloud
  output=`tar -xvf setuptools-0.7.2.tar.gz  2>&1 >> $logFilePath`
  cd /tmp/fit2cloud/setuptools-0.7.2

  #install Python2.7 first
  output=`python2.7 --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" == "0" ]; then
      output=`python2.7 setup.py install 2>&1 >> $logFilePath`
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`: "错误: /usr/bin/python2.7不存在, 请先安装python2.7!"
      exit 1
  fi
  echo `date "+%Y-%m-%d %H:%M:%S"`": 安装Setuptools完毕!"

  output=`python2.7 -c "from setuptools import setup, find_packages" 2>&1 >> $logFilePath`
  if [ $? == 0 ]; then
      echo `date "+%Y-%m-%d %H:%M:%S"`: "python-setuptools installed successfully!"
      exit 0
  else 
      echo `date "+%Y-%m-%d %H:%M:%S"`: "python-setuptools install failed!"
      exit 1
  fi
}


function validateToolInstalled
{
  toolName=$1
  output=`$toolName --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" == "1" ]; then
      return 1
  else
      return 0
  fi
}

function installByRepo
{
    #install by yum or apt-get
    repoType=""
    if [ "$installed" == "False" ];then
      output=`yum --help 2>&1 | grep "command not found" | wc -l`
      if [ "$output" == "0" ]; then
        repoType="yum"
        echo `date "+%Y-%m-%d %H:%M:%S"`": 从yum源安装$cmdName..."
        configureRepo
        echo `date "+%Y-%m-%d %H:%M:%S"`": f2c-timeout -t $timeoutTime yum install -y $cmdName ..."
        output=`f2c-timeout -t $timeoutTime yum install -y $cmdName 2>&1 >> $logFilePath`
        if [ $? != 0 ];then
            echo `date "+%Y-%m-%d %H:%M:%S"`: "waiting 5 secs to try the 2 time..."
            sleep 5
            output=`f2c-timeout -t $timeoutTime yum install -y $cmdName 2>&1 >> $logFilePath`
        fi
        if [ $?! = 0 ];then
            echo `date "+%Y-%m-%d %H:%M:%S"`: "waiting 5 secs to try the 3 time..."
            sleep 5
            output=`f2c-timeout -t $timeoutTime yum install -y $cmdName 2>&1 >> $logFilePath`
        fi
      fi
      output=`apt-get --help 2>&1 | grep "command not found" | wc -l`
      if [ "$output" == "0" ]; then
        repoType="apt-get"
        configureRepo
        echo `date "+%Y-%m-%d %H:%M:%S"`": 从apt-get源安装$cmdName..."
        echo `date "+%Y-%m-%d %H:%M:%S"`": f2c-timeout -t $timeoutTime apt-get install -y $cmdName ..."
        output=`export DEBIAN_FRONTEND=noninteractive;f2c-timeout -t $timeoutTime apt-get install -y $cmdName 2>&1 >> $logFilePath`
        if [ $? != 0 ];then
            echo `date "+%Y-%m-%d %H:%M:%S"`: "waiting 5 secs to try the 2 time..."
            sleep 5
            output=`f2c-timeout -t $timeoutTime apt-get install -y $cmdName 2>&1 >> $logFilePath`
        fi
        if [ $? != 0 ];then
            echo `date "+%Y-%m-%d %H:%M:%S"`: "waiting 5 secs to try the 3 time..."
            sleep 5
            output=`f2c-timeout -t $timeoutTime apt-get install -y $cmdName 2>&1 >> $logFilePath`
        fi
        OS=`cat /etc/issue | head -n 1 | awk '{print $1}'`
        if [ "$OS" == "Debian" ] ; then
            output=`f2c-timeout -t $timeoutTime apt-get install -y uuid-runtime 2>&1 >> $logFilePath`
            echo $output >> $logFilePath
        fi
      fi
      output=`zypper --help 2>&1 | grep "command not found" | wc -l`
      if [ "$output" == "0" ]; then
        repoType="zypper"
        configureRepo
        echo `date "+%Y-%m-%d %H:%M:%S"`": 从zypper源安装$cmdName..."
        echo `date "+%Y-%m-%d %H:%M:%S"`": f2c-timeout -t $timeoutTime zypper install -y $cmdName ..."
        output=`f2c-timeout -t $timeoutTime zypper install -y $cmdName 2>&1 >> $logFilePath`
        if [ $? != 0 ];then
            echo `date "+%Y-%m-%d %H:%M:%S"`: "waiting 5 secs to try the 2 time..."
            sleep 5
            output=`f2c-timeout -t $timeoutTime zypper install -y $cmdName 2>&1 >> $logFilePath`
        fi
        if [ $? != 0 ];then
            echo `date "+%Y-%m-%d %H:%M:%S"`: "waiting 5 secs to try the 3 time..."
            sleep 5
            output=`f2c-timeout -t $timeoutTime zypper install -y $cmdName 2>&1 >> $logFilePath`
        fi
      fi
    fi
}

function installBySource
{
  tmpDirName=`date +"%s"`
  downloadDirPath="/opt/tools/$cmdName/$tmpDirName"
  mkdir -p $downloadDirPath
  cd $downloadDirPath

  fileName=`echo $cmdSourceUrl | awk -F/  '{print $NF}'`

  output=`curl --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" == "0" ]; then
      output=`curl -L -o $downloadDirPath/$fileName --retry 3 --retry-delay 5 --connect-timeout 10 -m 180 $cmdSourceUrl 2>&1 >> $logFilePath`
  else
      output=`wget --help 2>&1 | grep "command not found" | wc -l`
      if [ "$output" == "0" ]; then
          output=`wget --tries=3 --timeout=600 -O $downloadDirPath/$fileName $cmdSourceUrl 2>&1 >> $logFilePath`
      else 
          #use f2c-wget download
          output=`f2c-wget $cmdSourceUrl`
      fi
  fi

  if [ -f $downloadDirPath/$fileName ];then
      echo `date "+%Y-%m-%d %H:%M:%S"`: "$fileName is downloaded to $downloadDirPath successfully!"
      #unzip or tar
      output=`echo $fileName | grep zip | wc -l`
      if [ "$output" == "1" ];then
          output=`unzip $downloadDirPath/$fileName`
      fi
      output=`echo $fileName | grep tar.gz | wc -l`
      if [ "$output" == "1" ];then
          output=`tar -zxvf $downloadDirPath/$fileName`
      fi

      unzipedDirName=`ls -l $downloadDirPath | grep "^d" | awk '{print $9}' | head -n 1`
      if [ -d $downloadDirPath/$unzipedDirName ];then
        echo `date "+%Y-%m-%d %H:%M:%S"`: "install from source in dir $downloadDirPath/$unzipedDirName"
        cd $downloadDirPath/$unzipedDirName
        output=`./configure 2>&1 >> $logFilePath`
        output=`make 2>&1 >> $logFilePath`
        output=`make install 2>&1 >> $logFilePath`
        echo `date "+%Y-%m-%d %H:%M:%S"`": $cmdName安装完毕!"
      fi
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`: "Error: $cmdName source download failed!"
  fi
   
  echo "validateName=$validateName"
  output=`$validateName --help 2>&1 | grep "command not found" | wc -l`
  if [ "$output" == "1" ]; then
      echo `date "+%Y-%m-%d %H:%M:%S"`: "error: install $cmdName failed!"
      exit 1
  else
      echo `date "+%Y-%m-%d %H:%M:%S"`": $cmdName installed successfully!"
      exit 0
  fi
}

function installNtp
{
   output=`$validateName --help 2>&1 | grep "command not found" | wc -l`
   if [ "$output" == "0" ]; then
       echo "ntpd already installed!"
       #Check ntpd status, if not running start it
       ntpStoped=`service ntpd status | grep stopped | wc -l`
       if [ "$ntpStoped" == "1" ];then
           echo "ntpd当前处于停止状态, 启动ntpd...."
           f2c-timeout -t 10 0.centos.pool.ntp.org
           service ntpd start
           service ntpd status
       fi
   else
       echo "ntpd没有安装，安装ntpd..."
       isCentOS=False
       which yum > /dev/null 2>&1
       if [ $? == 0 ];then
           isCentOS=True
           f2c-timeout -t 20 yum install -y ntp 2>&1 >> $logFilePath
           f2c-timeout -t 20 yum install -y ntp 2>&1 >> $logFilePath
           f2c-timeout -t 20 yum install -y ntp 2>&1 >> $logFilePath
       fi
       which apt-get > /dev/null 2>&1
       if [ $? == 0 ];then
           f2c-timeout -t 20 apt-get install -y ntp 2>&1 >> $logFilePath
           f2c-timeout -t 20 apt-get install -y ntp 2>&1 >> $logFilePath
           f2c-timeout -t 20 apt-get install -y ntp 2>&1 >> $logFilePath
       fi
       f2c-timeout -t 10 0.centos.pool.ntp.org
       service ntpd start
       if [ "$isCentOS" == "True" ];then
           chkconfig ntpd on
       else
           update-rc.d -f ntp remove
           update-rc.d ntp defaults 80
       fi
       
   fi
}

if [ "$cmdName" == "python2.7" ];then
    installPython27
elif [ "$cmdName" == "zlib" ];then
    installZlib
elif [ "$cmdName" == "setuptools" ];then
    installPythonSetupTools
elif [ "$cmdName" == "ntp" ];then
    installNtp
elif [ "$cmdName" == "openssl-devel" ];then
    installByRepo
else
    installByRepo
    output=`$validateName --help 2>&1 | grep "command not found" | wc -l`
    if [ "$output" == "1" ]; then
        installed=False
        echo `date "+%Y-%m-%d %H:%M:%S"`: "error: $cmdName install by $repoType failed!"
        echo `date "+%Y-%m-%d %H:%M:%S"`: "cmdSourceUrl=$cmdSourceUrl"
        echo `date "+%Y-%m-%d %H:%M:%S"`: "try install $cmdName from source..."
        if [ "x$cmdSourceUrl" == "x" ];then
            echo `date "+%Y-%m-%d %H:%M:%S"`: "error: source code download url is not provided!Please provide valid source download url"
            exit 1
        else
            echo `date "+%Y-%m-%d %H:%M:%S"`": 无法从yum,apt-get源安装，尝试从源代码安装" 
            installBySource
        fi
    else
        installed=True
        echo `date "+%Y-%m-%d %H:%M:%S"`: "$cmdName installed successfully by repo!"
        exit 0
    fi
fi
