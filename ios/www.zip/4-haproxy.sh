#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

while getopts a:h option
do
    case "$option" in
        a)
            action=$OPTARG
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            exit 1;;
    esac
done

baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)

if [ "$action" == "install"  ];then
  which haproxy > /dev/null 2>&1
  if [ $? == 0 ];then
      echo "Haproxy已经安装"
  else
     echo "Haproxy已经失败"
     exit 1
  fi
 
  cp $baseDirForScriptSelf/conf/haproxy.cfg.template /etc/haproxy/haproxy.cfg
  cp $baseDirForScriptSelf/conf/503.http /usr/share/haproxy/503.http
  service haproxy start
  
  serviceStatus=`service haproxy status | grep running | wc -l`
  if [ "x$serviceStatus" == "x1" ]; then
     echo "Haproxy启动成功"
  else
     echo "Haproxy启动失败"
   	 exit 1
  fi 
fi