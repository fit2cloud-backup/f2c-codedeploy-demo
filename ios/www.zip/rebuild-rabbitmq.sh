#!/bin/bash

# remove rabbitmq
rpm -e rabbitmq-server
rm -rf /etc/rabbitmq /var/lib/rabbitmq /var/log/rabbitmq /usr/lib/rabbitmq

# reinstall rabbitmq
rpm -i /opt/f2c-ops/rpm/rabbitmq-server-3.5.6-1.noarch.rpm

mqUser=`sed -n 's/rabbitmq.username=\(.*\).*/\1/p' /opt/fit2cloud/fit2cloud.properties`
mqPwd=`sed -n 's/rabbitmq.password=\(.*\).*/\1/p' /opt/fit2cloud/fit2cloud.properties`

cp /opt/f2c-ops/conf/rabbitmq.config.template /etc/rabbitmq/rabbitmq.config
cp /opt/f2c-ops/conf/rabbitmq-env.conf.template /etc/rabbitmq/rabbitmq-env.conf
service rabbitmq-server start
sleep 5
serviceStatus=`service rabbitmq-server status | grep {pid | wc -l`
if [ "x$serviceStatus" == "x1" ]; then
  rabbitmq-plugins enable rabbitmq_management
  rabbitmqctl delete_user guest
  rabbitmqctl delete_vhost /
  rabbitmqctl add_user ${mqUser} ${mqPwd}
  rabbitmqctl set_user_tags fit2cloud administrator
  rabbitmqctl add_vhost /fit2cloud
  rabbitmqctl set_permissions -p /fit2cloud fit2cloud "." "." ".*"
  echo "RabbitMQ启动成功"
else
  echo "RabbitMQ启动失败"
  exit 1
fi
