#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

componentId=$1
version=$2

function downloadComponent
{
  downloadsDirPath=/opt/fit2cloud/$version
  mkdir -p $downloadsDirPath
  cd $downloadsDirPath
  rm -rf $downloadsDirPath/$componentId-$version.war
  echo "下载组件$componentId Build..." >> $logFilePath
  output=`cp /opt/f2c-ops/war/${componentId}-${version}.war $downloadsDirPath/$componentId-$version.war 2>&1 >> $logFilePath`
  echo "下载组件$componentId Build完毕!" >> $logFilePath
}

downloadComponent