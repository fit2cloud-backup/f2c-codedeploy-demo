#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

function usage
{
    echo "Usage: args [-a action -c component -v version] [-e] [-r] [-d] [-m] [-h] [-l]"
    echo "-a means action, required"
    echo "-c means component, required"
    echo "-v means version, required"
    echo "-d means download build, optional"
    echo ""
    echo Examples:
    echo "Install webspace-webconsole 0.2"
    echo "  " ./f2c-ops.sh -a install -c webspace-webconsole -v 0.2
    echo "Redeploy webspace-webconsole 0.2"
    echo "  " ./f2c-ops.sh -a redeploy -c webspace-webconsole -v 0.2
    echo "Status webspace-webconsole 0.2"
    echo "  " ./f2c-ops.sh -a status -c webspace-webconsole -v 0.2
    echo "Stop webspace-webconsole 0.2"
    echo "  " ./f2c-ops.sh -a stop -c webspace-webconsole -v 0.2
    echo "Start webspace-webconsole 0.2"
    echo "  " ./f2c-ops.sh -a start -c webspace-webconsole -v 0.2
    echo ""
    echo "Deploy fit2cloud enterprise 0.2"
    echo "  " ./f2c-ops.sh -a deploycode -c f2c -v 0.2
    echo "Redeploy fit2cloud enterprise 0.2"
    echo "  " ./f2c-ops.sh -a redeploy -c f2c -v 0.2
    echo "Status fit2cloud enterprise 0.2"
    echo "  " ./f2c-ops.sh -a status -c f2c -v 0.2
    echo "Stop fit2cloud enterprise 0.2"
    echo "  " ./f2c-ops.sh -a stop -c f2c -v 0.2
    echo "Start fit2cloud enterprise 0.2"
    echo "  " ./f2c-ops.sh -a start -c f2c -v 0.2
}

while getopts a:c:v:drmelh option
do
    case "$option" in
        a)
            action=$OPTARG
            ;;
        c)
            componentId=$OPTARG
            ;;
        v)
            version=$OPTARG
            ;;
        d)
            skipDownload="no"
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            exit 1;;
    esac
done

DEBUG=0
if [ $DEBUG -eq 1 ];then
  echo "action=$action"
  echo "componentId=$componentId"
  echo "version=$version"
  echo "skipDownload=$skipDownload"
fi

if [ "x$componentId" == "x" ]; then
    usage
    exit 1
fi

componentIds="webspace-webconsole webspace-scheduler webspace-restapi jobserver-producer jobserver-worker eventengine-producer eventengine-consumer eventengine-dispatcher"

if [ "$componentId" == "f2c" ] ; then
  toInstallComponentIds=$componentIds
else
  toInstallComponentIds=$componentId
fi

baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)

homeDirPath=/opt/fit2cloud
configDirPath=/opt/fit2cloud

function downloadComponent
{
  echo "Downloading component $componentId $version build" >> $logFilePath
  bash $baseDirForScriptSelf/0-download-build.sh $componentId $version
  if [ -e "/opt/fit2cloud/$version/$componentId-$version.war" ] ; then
      echo "$componentId-$version.war downloaded"
      echo "Download $componentId $version build successfully!" >> $logFilePath
      mv "/opt/fit2cloud/$version/$componentId-$version.war" "/opt/fit2cloud/$version/$componentId-$version.jar"
  else
      echo "Failed to download $componentId-$version.jar"
      echo "Download $componentId $version build failed!" >> $logFilePath
  fi
}

function statusComponent
{
  pid=`ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" | awk '{print $2}'`
  if [ "x$pid" == "x" ];then
     echo "$componentId is stopped"
  else
     pid=`ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" | awk '{print $2}'`
     echo "PID=$pid $componentId is running"
  fi
}

function stopComponent
{
  pid=`ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" | awk '{print $2}'`
  if [ "x$pid" == "x" ];then
     echo "$componentId stopped"
  else
     ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" | awk '{print "kill -9 " $2}' | bash
     pid=`ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" | awk '{print $2}'`
     if [ "x$pid" == "x" ];then
         echo "$componentId stopped"
     fi
  fi
}

function startComponent
{
  f2cLogDirPath="/var/log/fit2cloud"
  echo -------------------------------------------------------- >> $logFilePath
  echo "start $componentId" >> $logFilePath
  startOptions="-Xms768m -Xmx768m -XX:MaxPermSize=160m"
  if [ "$componentId" == "webspace-webconsole" ];then
      startOptions="-Xms1024m -Xmx1024m -XX:MaxPermSize=160m"
  fi
  if [ "$componentId" == "webspace-scheduler" ];then
      startOptions="-Xms1024m -Xmx1024m -XX:MaxPermSize=160m"
  fi
  if [ -e "$homeDirPath/$version/$componentId-$version.jar" ]; then
      pid=`ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" | awk '{print $2}'`
      if [ "x$pid" == "x" ];then
          mkdir -p $f2cLogDirPath
          mkdir -p /opt/fit2cloud/tmp
          nohup java -Dfile.encoding=utf-8 -Djava.io.tmpdir=/opt/fit2cloud/tmp $startOptions -jar $homeDirPath/$version/$componentId-$version.jar >> $f2cLogDirPath/$componentId-$version-console.log 2>&1 &
          sleep 1
          pid=`ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" | awk '{print $2}'`
          if [ "x$pid" != "x" ];then
              sleep 3
              echo "$componentId started"
          else
              echo "start $componentId"
          fi
      else
          echo "$componentId already started"
          ps aux | grep "$componentId" | grep jar | grep -v grep | grep "/opt/fit2cloud" >> $logFilePath
      fi
  else
      echo "ERROR: $homeDirPath/$version/$componentId-$version.jar is not deployed!"
  fi
}

#4. Download Component or components
if [ "$action" == "download" ];then
  mkdir /opt/fit2cloud
  cp $baseDirForScriptSelf/conf/fit2cloud.properties.template $configDirPath/fit2cloud.properties
  cp $baseDirForScriptSelf/conf/job.xml.template $configDirPath/job.xml
  for componentId in $toInstallComponentIds;
  do
    downloadComponent $componentId
  done
fi

#5. Stop component or components
if [ "$action" == "stop" ];then
  for componentId in $toInstallComponentIds;
  do
    stopComponent $componentId
  done
fi

#6. Start component or components
if [ "$action" == "start" ];then
  for componentId in $toInstallComponentIds;
  do
    startComponent $componentId
  done
fi

#7. Status component or components
if [ "$action" == "status" ];then
  for componentId in $toInstallComponentIds;
  do
    statusComponent $componentId
  done
fi

#8. Redeploy component or components
if [ "$action" == "redeploy" ];then
  if [ "$componentId" == "f2c" ] ; then
    bash $baseDirForScriptSelf/patch_jdk.sh
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a install -p ksyun -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p aws -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p aliyun -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p qingcloud -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p ucloud -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p qcloud -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p azure -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p ksyun -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p qingcloud-enterprise -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p openstackV1 -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p openstackV2 -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p vsphere55 -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p vsphere60 -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p fusioncompute -v 0.2
    bash $baseDirForScriptSelf/6-f2c-plugin.sh -a redeploy -p vcloud -v 0.2
    cp -r /opt/f2c-ops/repos/* /var/www/fit2cloud/
  fi
  for componentId in $toInstallComponentIds;
  do
    echo "Start redeploy $componentId ... ..."  >> $logFilePath
    echo "componentId=$componentId"  >> $logFilePath
    stopComponent $componentId $version
    downloadComponent $componentId $version
    startComponent $componentId $version
    echo "$componentId $version is installed: `date` " >> /opt/fit2cloud/install_history.txt
    echo "End install $componentId." >> $logFilePath
  done
  exit 0;
fi

#9. deploy component or components code only
if [ "$action" == "deploycode" ];then
  mkdir /opt/fit2cloud
  cp $baseDirForScriptSelf/conf/fit2cloud.properties.template $configDirPath/fit2cloud.properties
  cp $baseDirForScriptSelf/conf/job.xml.template $configDirPath/job.xml
  for componentId in $toInstallComponentIds;
  do
    echo ---------------------------------------------- >> $logFilePath
    echo "Start deploy $componentId code... ..." >> $logFilePath
    downloadComponent $componentId $version
    echo "End deploy $componentId code.." >> $logFilePath
  done
fi
