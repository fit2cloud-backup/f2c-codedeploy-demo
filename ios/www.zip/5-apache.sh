#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

while getopts a:h option
do
    case "$option" in
        a)
            action=$OPTARG
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            exit 1;;
    esac
done

baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)

function configure {
  output=`semanage port -a -t http_port_t -p tcp 6605  2>&1 >> $logFilePath`
  cp $baseDirForScriptSelf/conf/httpd.conf.template /etc/httpd/conf/httpd.conf
  mkdir /var/www/fit2cloud
  cp -R $baseDirForScriptSelf/repos/* /var/www/fit2cloud
}

if [ "$action" == "install"  ];then
  which httpd > /dev/null 2>&1
  if [ $? == 0 ];then
      echo "apache安装已经安装!"
  else 
     echo "apache安装失败!"
     exit 1
  fi
  configure
  service httpd restart
  
  serviceStatus=`service httpd status | grep running | wc -l`
  if [ "x$serviceStatus" == "x1" ]; then
     echo "Apache安装成功"
  else
     echo "Apache安装失败"
   	 exit 1
  fi   
fi