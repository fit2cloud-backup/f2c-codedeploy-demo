#!/bin/bash

logFilePath="/var/log/f2c-ops.log"

while getopts a:h option
do
    case "$option" in
        a)
            action=$OPTARG
            ;;
        h)
            echo "option:h"
            ;;
        \?)
            exit 1;;
    esac
done

baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)
source /root/.bash_profile

function installRabbitMQ
{
  which erl > /dev/null 2>&1
  if [ $? == 0 ];then
      echo "erlang已经安装"
  else
      echo "安装erlang失败"
      exit 1
  fi

  which rabbitmqctl > /dev/null 2>&1
  if [ $? == 0 ];then
      echo "RabbitMQ已经安装"
  else
      echo "安装RabbitMQ失败"
      exit 1
  fi
  cp /opt/f2c-ops/conf/rabbitmq.config.template /etc/rabbitmq/rabbitmq.config
  cp /opt/f2c-ops/conf/rabbitmq-env.conf.template /etc/rabbitmq/rabbitmq-env.conf
  service rabbitmq-server start
  sleep 5
  serviceStatus=`service rabbitmq-server status | grep {pid | wc -l`
  if [ "x$serviceStatus" == "x1" ]; then
     rabbitmq-plugins enable rabbitmq_management  
     rabbitmqctl delete_user guest
     rabbitmqctl delete_vhost /
     rabbitmqctl add_user ${username} ${password}
     rabbitmqctl set_user_tags ${username} administrator
     rabbitmqctl add_vhost /fit2cloud
     rabbitmqctl set_permissions -p /fit2cloud ${username} "." "." ".*"
     echo "RabbitMQ启动成功"
  else
     echo "RabbitMQ启动失败"
   	 exit 1
  fi 
}

if [ "$action" == "install"  ];then
  installRabbitMQ
fi

