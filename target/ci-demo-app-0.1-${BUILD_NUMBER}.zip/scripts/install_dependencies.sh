#!/bin/bash

echo install dependencies
