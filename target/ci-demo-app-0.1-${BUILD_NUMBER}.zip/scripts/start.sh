cd /opt/fit2cloud-demo
nohup python -m SimpleHTTPServer 8080 > log.txt 2>&1 &
