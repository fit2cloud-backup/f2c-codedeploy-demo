#!/bin/bash

echo configure after deploy code
